This directory contains the external libraries required for building the 
product, but which are not necessary to use it.
