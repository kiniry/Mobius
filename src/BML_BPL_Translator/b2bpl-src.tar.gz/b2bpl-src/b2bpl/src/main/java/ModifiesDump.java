import java.io.FileOutputStream;
import java.io.OutputStream;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import b2bpl.bytecode.attributes.MethodSpecificationAttribute;
import b2bpl.bytecode.bml.ast.BMLBooleanLiteral;
import b2bpl.bytecode.bml.ast.BMLEnsuresClause;
import b2bpl.bytecode.bml.ast.BMLExsuresClause;
import b2bpl.bytecode.bml.ast.BMLMethodSpecification;
import b2bpl.bytecode.bml.ast.BMLModifiesClause;
import b2bpl.bytecode.bml.ast.BMLNothingStoreRef;
import b2bpl.bytecode.bml.ast.BMLPredicate;
import b2bpl.bytecode.bml.ast.BMLRequiresClause;
import b2bpl.bytecode.bml.ast.BMLSpecificationCase;
import b2bpl.bytecode.bml.ast.BMLStoreRef;


public class ModifiesDump implements Opcodes {

  public static byte[] dump() throws Exception {

    ClassWriter cw = new ClassWriter(0);
    FieldVisitor fv;
    MethodVisitor mv;
    AnnotationVisitor av0;

    cw.visit(
        V1_5,
        ACC_PUBLIC + ACC_SUPER,
        "Modifies",
        null,
        "java/lang/Object",
        null);

    cw.visitSource("Modifies.java", null);

    {
      fv = cw.visitField(ACC_PRIVATE, "x", "I", null, null);
      fv.visitEnd();
    }
    {
      mv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
      mv.visitCode();
      mv.visitVarInsn(ALOAD, 0);
      mv.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V");
      mv.visitInsn(RETURN);
      mv.visitMaxs(1, 1);
      mv.visitEnd();
    }
    {
      mv = cw.visitMethod(ACC_PUBLIC, "modifiesNothing", "()V", null, null);

      BMLRequiresClause requires = new BMLRequiresClause(new BMLPredicate(
          BMLBooleanLiteral.TRUE));
      BMLModifiesClause modifies = new BMLModifiesClause(
          new BMLStoreRef[] { BMLNothingStoreRef.NOTHING });
      BMLEnsuresClause ensures = new BMLEnsuresClause(new BMLPredicate(
          BMLBooleanLiteral.TRUE));
      BMLExsuresClause[] exsures = BMLExsuresClause.EMPTY_ARRAY;

      BMLSpecificationCase specCase = new BMLSpecificationCase(
          requires,
          modifies,
          ensures,
          exsures);

      BMLMethodSpecification spec = new BMLMethodSpecification(
          requires,
          specCase);

      MethodSpecificationAttribute attr = new MethodSpecificationAttribute(spec);

      mv.visitAttribute(attr);

      mv.visitCode();
      mv.visitTypeInsn(NEW, "Modifies");
      mv.visitInsn(DUP);
      mv.visitMethodInsn(INVOKESPECIAL, "Modifies", "<init>", "()V");
      mv.visitVarInsn(ASTORE, 1);
      mv.visitVarInsn(ALOAD, 1);
      mv.visitIntInsn(BIPUSH, 7);
      mv.visitFieldInsn(PUTFIELD, "Modifies", "x", "I");
      mv.visitInsn(RETURN);
      mv.visitMaxs(2, 2);
      mv.visitEnd();
    }
    cw.visitEnd();

    return cw.toByteArray();
  }

  public static void main(String[] args) throws Exception {
    byte[] data = dump();
    OutputStream out = new FileOutputStream("target/classes/Modifies.class");
    out.write(data);
    out.close();
  }
}
