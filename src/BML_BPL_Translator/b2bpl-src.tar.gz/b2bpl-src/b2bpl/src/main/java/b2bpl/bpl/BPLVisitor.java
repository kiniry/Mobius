package b2bpl.bpl;

import b2bpl.bpl.ast.BPLArrayExpression;
import b2bpl.bpl.ast.BPLArrayType;
import b2bpl.bpl.ast.BPLAssertCommand;
import b2bpl.bpl.ast.BPLAssignmentCommand;
import b2bpl.bpl.ast.BPLAssumeCommand;
import b2bpl.bpl.ast.BPLAxiom;
import b2bpl.bpl.ast.BPLBasicBlock;
import b2bpl.bpl.ast.BPLBinaryArithmeticExpression;
import b2bpl.bpl.ast.BPLBinaryLogicalExpression;
import b2bpl.bpl.ast.BPLBoolLiteral;
import b2bpl.bpl.ast.BPLBuiltInType;
import b2bpl.bpl.ast.BPLCallCommand;
import b2bpl.bpl.ast.BPLCastExpression;
import b2bpl.bpl.ast.BPLConstantDeclaration;
import b2bpl.bpl.ast.BPLTypeName;
import b2bpl.bpl.ast.BPLEnsuresClause;
import b2bpl.bpl.ast.BPLEqualityExpression;
import b2bpl.bpl.ast.BPLFunction;
import b2bpl.bpl.ast.BPLFunctionApplication;
import b2bpl.bpl.ast.BPLFunctionParameter;
import b2bpl.bpl.ast.BPLGotoCommand;
import b2bpl.bpl.ast.BPLHavocCommand;
import b2bpl.bpl.ast.BPLImplementation;
import b2bpl.bpl.ast.BPLImplementationBody;
import b2bpl.bpl.ast.BPLIntLiteral;
import b2bpl.bpl.ast.BPLLogicalNotExpression;
import b2bpl.bpl.ast.BPLModifiesClause;
import b2bpl.bpl.ast.BPLNullLiteral;
import b2bpl.bpl.ast.BPLOldExpression;
import b2bpl.bpl.ast.BPLParameterizedType;
import b2bpl.bpl.ast.BPLPartialOrderExpression;
import b2bpl.bpl.ast.BPLProcedure;
import b2bpl.bpl.ast.BPLProgram;
import b2bpl.bpl.ast.BPLQuantifierExpression;
import b2bpl.bpl.ast.BPLRelationalExpression;
import b2bpl.bpl.ast.BPLRequiresClause;
import b2bpl.bpl.ast.BPLReturnCommand;
import b2bpl.bpl.ast.BPLSpecification;
import b2bpl.bpl.ast.BPLTrigger;
import b2bpl.bpl.ast.BPLTypeDeclaration;
import b2bpl.bpl.ast.BPLUnaryMinusExpression;
import b2bpl.bpl.ast.BPLVariable;
import b2bpl.bpl.ast.BPLVariableDeclaration;
import b2bpl.bpl.ast.BPLVariableExpression;


public interface BPLVisitor {

  void visitProgram(BPLProgram program);

  void visitAxiom(BPLAxiom axiom);

  void visitConstantDeclaration(BPLConstantDeclaration declaration);

  void visitImplementation(BPLImplementation implementation);

  void visitProcedure(BPLProcedure procedure);

  void visitTypeDeclaration(BPLTypeDeclaration declaration);

  void visitVariableDeclaration(BPLVariableDeclaration declaration);

  void visitVariable(BPLVariable variable);

  void visitFunction(BPLFunction function);

  void visitFunctionParameter(BPLFunctionParameter parameter);

  void visitSpecification(BPLSpecification specification);

  void visitRequiresClause(BPLRequiresClause clause);

  void visitModifiesClause(BPLModifiesClause clause);

  void visitEnsuresClause(BPLEnsuresClause clause);

  void visitImplementationBody(BPLImplementationBody body);

  void visitBasicBlock(BPLBasicBlock block);

  void visitAssertCommand(BPLAssertCommand command);

  void visitAssumeCommand(BPLAssumeCommand command);

  void visitAssignmentCommand(BPLAssignmentCommand command);

  void visitCallCommand(BPLCallCommand command);

  void visitHavocCommand(BPLHavocCommand command);

  void visitGotoCommand(BPLGotoCommand command);

  void visitReturnCommand(BPLReturnCommand command);

  void visitArrayExpression(BPLArrayExpression expr);

  void visitBinaryArithmeticExpression(BPLBinaryArithmeticExpression expr);

  void visitBinaryLogicalExpression(BPLBinaryLogicalExpression expr);

  void visitEqualityExpression(BPLEqualityExpression expr);

  void visitPartialOrderExpression(BPLPartialOrderExpression expr);

  void visitRelationalExpression(BPLRelationalExpression expr);

  void visitCastExpression(BPLCastExpression expr);

  void visitFunctionApplication(BPLFunctionApplication expr);

  void visitBoolLiteral(BPLBoolLiteral literal);

  void visitIntLiteral(BPLIntLiteral literal);

  void visitNullLiteral(BPLNullLiteral literal);

  void visitOldExpression(BPLOldExpression expr);

  void visitQuantifierExpression(BPLQuantifierExpression expr);

  void visitLogicalNotExpression(BPLLogicalNotExpression expr);

  void visitUnaryMinusExpression(BPLUnaryMinusExpression expr);

  void visitVariableExpression(BPLVariableExpression expr);

  void visitTrigger(BPLTrigger trigger);

  void visitBuiltInType(BPLBuiltInType type);

  void visitTypeName(BPLTypeName type);

  void visitArrayType(BPLArrayType type);

  void visitParameterizedType(BPLParameterizedType type);
}
