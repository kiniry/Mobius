package b2bpl.bpl.ast;

import b2bpl.bpl.BPLVisitor;


public class BPLArrayExpression extends BPLExpression {

  private final BPLExpression prefix;

  private final BPLExpression[] accessors;

  public BPLArrayExpression(BPLExpression prefix, BPLExpression... accessors) {
    super(Precedence.ATOM);
    this.prefix = prefix;
    this.accessors = accessors;
  }

  public BPLExpression getPrefix() {
    return prefix;
  }

  public BPLExpression[] getAccessors() {
    return accessors;
  }

  public void accept(BPLVisitor visitor) {
    visitor.visitArrayExpression(this);
  }
}
