package b2bpl.bpl.ast;

import b2bpl.bpl.BPLVisitor;


public class BPLAxiom extends BPLDeclaration {

  private final BPLExpression expression;

  public BPLAxiom(BPLExpression expression) {
    this.expression = expression;
  }

  public BPLExpression getExpression() {
    return expression;
  }

  public void accept(BPLVisitor visitor) {
    visitor.visitAxiom(this);
  }

  public String toString() {
    return "axiom " + expression + ";";
  }
}
