package b2bpl.bpl.ast;


public abstract class BPLDeclaration extends BPLNode {

  public static final BPLDeclaration[] EMPTY_ARRAY = new BPLDeclaration[0];
}
