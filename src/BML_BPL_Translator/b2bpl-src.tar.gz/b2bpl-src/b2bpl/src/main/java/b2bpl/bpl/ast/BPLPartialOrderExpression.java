package b2bpl.bpl.ast;

import b2bpl.bpl.BPLVisitor;


public class BPLPartialOrderExpression extends BPLBinaryExpression {

  public BPLPartialOrderExpression(BPLExpression left, BPLExpression right) {
    super(Precedence.RELATIONAL, left, right);
  }

  public boolean isLeftAssociativeTo(BPLExpression other) {
    return false;
  }

  public boolean isRightAssociativeTo(BPLExpression other) {
    return false;
  }

  public void accept(BPLVisitor visitor) {
    visitor.visitPartialOrderExpression(this);
  }

  public String toString() {
    return opndToString(left) + " <: " + opndToString(right);
  }
}
