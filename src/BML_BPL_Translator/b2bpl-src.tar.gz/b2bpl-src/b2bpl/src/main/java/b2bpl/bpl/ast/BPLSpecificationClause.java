package b2bpl.bpl.ast;


public abstract class BPLSpecificationClause extends BPLNode {

}
