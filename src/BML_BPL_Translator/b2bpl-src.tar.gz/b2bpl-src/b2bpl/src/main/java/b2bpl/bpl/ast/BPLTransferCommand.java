package b2bpl.bpl.ast;


public abstract class BPLTransferCommand extends BPLNode {

}
