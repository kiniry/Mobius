package b2bpl.bpl.ast;

import b2bpl.bpl.BPLVisitor;


public class BPLTrigger extends BPLNode {

  public static final BPLTrigger[] EMPTY_ARRAY = new BPLTrigger[0];

  private final BPLExpression[] expressions;

  public BPLTrigger(BPLExpression... expressions) {
    this.expressions = expressions;
  }

  public BPLExpression[] getExpressions() {
    return expressions;
  }

  public void accept(BPLVisitor visitor) {
    visitor.visitTrigger(this);
  }
}
