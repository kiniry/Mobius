package b2bpl.bytecode;

import java.util.HashMap;

import b2bpl.bytecode.bml.ast.BMLInvariant;


public class JClassType extends JReferenceType implements Constants {

  public static final JClassType[] EMPTY_ARRAY = new JClassType[0];

  private final String name;

  private int accessModifiers;

  private JClassType supertype = null;

  private JClassType[] interfaces;

  private BCField[] fields;

  private BCMethod[] methods;

  private BMLInvariant[] invariants;

  private HashMap<String, BCField> fieldsMap;

  private HashMap<String, BCMethod> methodsMap;

  public JClassType(String name) {
    this.name = name.replace('/', '.');
  }

  public String getName() {
    return name;
  }

  public String getInternalName() {
    return name.replace('.', '/');
  }

  public String getDescriptor() {
    return "L" + getInternalName() + ";";
  }

  public boolean isClassType() {
    return true;
  }

  public int getAccessModifiers() {
    TypeLoader.loadType(this);
    return accessModifiers;
  }

  public JClassType getSupertype() {
    TypeLoader.loadType(this);
    return supertype;
  }

  public JClassType[] getInterfaces() {
    TypeLoader.loadType(this);
    return interfaces;
  }

  void setTypeInfo(
      int accessModifiers,
      JClassType supertype,
      JClassType[] interfaces) {
    this.accessModifiers = accessModifiers;
    this.supertype = supertype;
    this.interfaces = interfaces;
  }

  public boolean isInterface() {
    return (getAccessModifiers() & ACC_INTERFACE) != 0;
  }

  public boolean isPublic() {
    return (getAccessModifiers() & ACC_PUBLIC) != 0;
  }

  public boolean isPrivate() {
    return (getAccessModifiers() & ACC_PRIVATE) != 0;
  }

  public boolean isProtected() {
    return (getAccessModifiers() & ACC_PROTECTED) != 0;
  }

  public boolean isPackageProtected() {
    return !(isPublic() || isPrivate() || isProtected());
  }

  public boolean isAbstract() {
    return (getAccessModifiers() & ACC_ABSTRACT) != 0;
  }

  public boolean isFinal() {
    return (getAccessModifiers() & ACC_FINAL) != 0;
  }

  public BCField[] getFields() {
    TypeLoader.loadType(this);
    return fields;
  }

  public BCMethod[] getMethods() {
    TypeLoader.loadType(this);
    return methods;
  }

  public BMLInvariant[] getInvariants() {
    TypeLoader.loadType(this);
    return invariants;
  }

  void setDeclarations(
      BCField[] fields,
      BCMethod[] methods,
      BMLInvariant[] invariants) {
    this.fields = fields;
    this.methods = methods;
    this.invariants = invariants;

    fieldsMap = new HashMap<String, BCField>();
    for (BCField field : fields) {
      fieldsMap.put(field.getName(), field);
    }

    methodsMap = new HashMap<String, BCMethod>();
    for (BCMethod method : methods) {
      methodsMap.put(method.getName() + method.getDescriptor(), method);
    }
  }

  public boolean isSubtypeOf(JType type) {
    if (type.isClassType()) {
      if (equals(type)) {
        return true;
      }
      if ((getSupertype() != null) && (getSupertype().isSubtypeOf(type))) {
        return true;
      }
      for (JClassType iface : getInterfaces()) {
        if (iface.isSubtypeOf(type)) {
          return true;
        }
      }
    }
    return false;
  }

  public BCField getField(String name) {
    TypeLoader.loadType(this);
    return fieldsMap.get(name);
  }

  public BCMethod getMethod(String name, String descriptor) {
    TypeLoader.loadType(this);
    return methodsMap.get(name + descriptor);
  }

  public BCField lookupField(String name) {
    BCField field = getField(name);
    if (field != null) {
      return field;
    }
    if (getSupertype() != null) {
      field = getSupertype().lookupField(name);
      if (field != null) {
        return field;
      }
    }
    for (JClassType iface : getInterfaces()) {
      field = iface.lookupField(name);
      if (field != null) {
        return field;
      }
    }
    return null;
  }

  public BCMethod lookupMethod(String name, String descriptor) {
    BCMethod method = getMethod(name, descriptor);
    if (method != null) {
      return method;
    }
    if (getSupertype() != null) {
      method = getSupertype().lookupMethod(name, descriptor);
      if (method != null) {
        return method;
      }
    }
    for (JClassType iface : getInterfaces()) {
      method = iface.lookupMethod(name, descriptor);
      if (method != null) {
        return method;
      }
    }
    return null;
  }

  public String toString() {
    return name;
  }
}
