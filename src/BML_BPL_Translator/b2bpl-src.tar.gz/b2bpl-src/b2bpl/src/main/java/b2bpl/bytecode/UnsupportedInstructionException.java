package b2bpl.bytecode;


public class UnsupportedInstructionException extends RuntimeException {

  private static final long serialVersionUID = -3952540367225723149L;

  public UnsupportedInstructionException(String message) {
    super(message);
  }
}
