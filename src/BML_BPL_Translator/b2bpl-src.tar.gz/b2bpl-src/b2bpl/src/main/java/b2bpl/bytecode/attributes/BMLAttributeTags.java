package b2bpl.bytecode.attributes;


public interface BMLAttributeTags {

  int TRUE = 0x00;

  int FALSE = 0x01;

  int AND = 0x02;

  int OR = 0x03;

  int IMPLIES = 0x04;

  int NOT = 0x05;

  int FORALL = 0x06;

  int EXISTS = 0x07;

  int EQUALS = 0x10;

  int GREATER = 0x11;

  int LESS = 0x12;

  int LESS_EQUAL = 0x13;

  int GREATER_EQUAL = 0x14;

  int INSTANCEOF = 0x15;

  int SUBTYPE = 0x16;

  int NOT_EQUALS = 0x17;

  int PLUS = 0x20;

  int MINUS = 0x21;

  int TIMES = 0x22;

  int DIVIDE = 0x23;

  int REMAINDER = 0x24;

  int UNARY_MINUS = 0x25;

  int BITWISE_AND = 0x30;

  int BITWISE_OR = 0x31;

  int BITWISE_XOR = 0x32;

  int SHL = 0x33;

  int SHR = 0x34;

  int USHR = 0x35;

  int INT_LITERAL = 0x40;

  int CHAR_LITERAL = 0x41;

  int TYPE_OF = 0x50; // \typeof(expr) : \TYPE

  int ELEM_TYPE = 0x51; //  \elemtype(array_expr)

  int RESULT = 0x52; //  \result
  //    int ALL_ARRAY_ELEM =  0x53; // *

  int type = 0x54; //  \type(javaType)  : \TYPE

  int TYPE = 0x55; //  \TYPE

  int ARRAY_LENGTH = 0x56;

  int METHOD_CALL = 0x60;

  int ARRAY_ACCESS = 0x61;

  int CAST = 0x62;

  int FIELD_ACCESS = 0x63;

  int CONDITIONAL_EXPRESSION = 0x64;

  int THIS = 0x70;

  int OLD_THIS = 0x71;

  int NULL = 0x72;

  int FIELD = 0x80;

  int OLD_FIELD = 0x81;

  int LOCAL_VARIABLE = 0x90;

  int OLD_LOCAL_VARIABLE = 0x91;

  int MODEL_FIELD = 0xA0;

  int OLD_MODEL_FIELD = 0xA1;

  int METHOD = 0xB0;

  int JAVA_TYPE = 0xC0;

  int MODIFIES_EVERYTHING = 0xD0;

  int MODIFIES_NOTHING = 0xD1;

  int MODIFIES_IDENT = 0xD2;

  int MODIFIES_DOT = 0xD3;

  int MODIFIES_ARRAY = 0xD4;

  int MODIFIES_ARRAY_INDEX = 0xD5;

  int MODIFIES_ARRAY_INTERVAL = 0xD6;

  int MODIFIES_ARRAY_STAR = 0xD7;

  int BOUND_VARIABLE = 0xE0;

  int STACK_ELEMENT = 0xF0;

  int STACK_COUNTER = 0xF1;
}
