package b2bpl.bytecode.bml.ast;

import b2bpl.bytecode.bml.BMLExpressionVisitor;


public class BMLArrayAccessExpression extends BMLExpression {

  private final BMLExpression prefix;

  private final BMLExpression index;

  public BMLArrayAccessExpression(BMLExpression prefix, BMLExpression field) {
    this.prefix = prefix;
    this.index = field;
  }

  public BMLExpression getPrefix() {
    return prefix;
  }

  public BMLExpression getIndex() {
    return index;
  }

  public <R> R accept(BMLExpressionVisitor<R> visitor) {
    return visitor.visitArrayAccessExpression(this);
  }

  public String toString() {
    return prefix + "[" + index + "]";
  }
}
