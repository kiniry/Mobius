package b2bpl.bytecode.bml.ast;

import b2bpl.bytecode.bml.BMLExpressionVisitor;


public class BMLBinaryLogicalExpression extends BMLBinaryExpression {

  private final Operator operator;

  public BMLBinaryLogicalExpression(
      Operator operator,
      BMLExpression left,
      BMLExpression right) {
    super(left, right);
    this.operator = operator;
  }

  public Operator getOperator() {
    return operator;
  }

  public <R> R accept(BMLExpressionVisitor<R> visitor) {
    return visitor.visitBinaryLogicalExpression(this);
  }

  public String toString() {
    return left + " " + operator + " " + right;
  }

  public static enum Operator {

    AND("&&"),

    OR("||"),

    IMPLIES("==>"),

    EQUIVALENCE("<==>");

    private final String token;

    private Operator(String token) {
      this.token = token;
    }

    public String toString() {
      return token;
    }
  }
}
