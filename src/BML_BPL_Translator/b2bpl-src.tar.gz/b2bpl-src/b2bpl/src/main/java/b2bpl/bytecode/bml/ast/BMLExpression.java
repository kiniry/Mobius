package b2bpl.bytecode.bml.ast;

import b2bpl.bytecode.JType;
import b2bpl.bytecode.bml.BMLExpressionVisitor;


public abstract class BMLExpression extends BMLNode {

  private JType type;

  public final JType getType() {
    return type;
  }

  public final void setType(JType type) {
    this.type = type;
  }

  public abstract <R> R accept(BMLExpressionVisitor<R> visitor);
}
