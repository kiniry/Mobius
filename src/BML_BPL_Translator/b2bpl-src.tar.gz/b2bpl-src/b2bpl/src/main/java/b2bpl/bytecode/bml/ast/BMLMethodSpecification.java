package b2bpl.bytecode.bml.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import b2bpl.bytecode.JType;


public class BMLMethodSpecification extends BMLNode {

  private final BMLRequiresClause requires;

  private final BMLSpecificationCase[] cases;

  private BMLPredicate precondition;

  private BMLPredicate postcondition;

  private BMLStoreRef[] storeRefs;

  private HashMap<JType, BMLPredicate> exceptionalPostconditions =
    new HashMap<JType, BMLPredicate>();

  public BMLMethodSpecification(
      BMLRequiresClause requires,
      BMLSpecificationCase... cases) {
    this.requires = requires;
    this.cases = cases;
  }

  public BMLRequiresClause getRequires() {
    return requires;
  }

  public BMLSpecificationCase[] getCases() {
    return cases;
  }

  public BMLPredicate getPrecondition() {
    if (precondition == null) {
      BMLExpression pre;
      if (cases.length == 0) {
        pre = BMLBooleanLiteral.TRUE;
      } else if (cases.length == 1) {
        // REVIEW[om]: This is a temporary hack to cope with what JACK gives us.
        pre = requires.getPredicate();
      } else {
        pre = cases[0].getRequires().getPredicate();
        for (int i = 1; i < cases.length; i++) {
          pre = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.OR,
              pre,
              cases[i].getRequires().getPredicate());
        }
      }
      precondition = new BMLPredicate(pre);
    }
    return precondition;
  }

  public BMLPredicate getPostcondition() {
    if (postcondition == null) {
      BMLExpression post;
      if (cases.length == 0) {
        post = BMLBooleanLiteral.TRUE;
      } else if (cases.length == 1) {
        // REVIEW[om]: This is a temporary hack to cope with what JACK gives us.
        post = new BMLBinaryLogicalExpression(
            BMLBinaryLogicalExpression.Operator.IMPLIES,
            requires.getPredicate(),
            cases[0].getEnsures().getPredicate());
      } else {
        post = new BMLBinaryLogicalExpression(
            BMLBinaryLogicalExpression.Operator.IMPLIES,
            cases[0].getRequires().getPredicate(),
            cases[0].getEnsures().getPredicate());
        for (int i = 1; i < cases.length; i++) {
          BMLExpression implication = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.IMPLIES,
              cases[i].getRequires().getPredicate(),
              cases[i].getEnsures().getPredicate());
          post = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.AND,
              post,
              implication);
        }
      }
      postcondition = new BMLPredicate(post);
    }
    return postcondition;
  }

  public BMLPredicate getExceptionalPostcondition(JType exception) {
    if (!exceptionalPostconditions.containsKey(exception)) {
      BMLExpression post;
      if (cases.length == 0) {
        post = BMLBooleanLiteral.TRUE;
      } else if (cases.length == 1) {
        // REVIEW[om]: This is a temporary hack to cope with what JACK gives us.
        post = new BMLBinaryLogicalExpression(
            BMLBinaryLogicalExpression.Operator.IMPLIES,
            requires.getPredicate(),
            getExceptionalPostcondition(exception, cases[0].getExsures()));
      } else {
        post = new BMLBinaryLogicalExpression(
            BMLBinaryLogicalExpression.Operator.IMPLIES,
            cases[0].getRequires().getPredicate(),
            getExceptionalPostcondition(exception, cases[0].getExsures()));
        for (int i = 1; i < cases.length; i++) {
          BMLExpression implication = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.IMPLIES,
              cases[i].getRequires().getPredicate(),
              getExceptionalPostcondition(exception, cases[i].getExsures()));
          post = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.AND,
              post,
              implication);
        }
      }
      exceptionalPostconditions.put(exception, new BMLPredicate(post));
    }
    return exceptionalPostconditions.get(exception);
  }

  public BMLStoreRef[] getStoreRefs() {
    if (storeRefs == null) {
      List<BMLStoreRef> accum = new ArrayList<BMLStoreRef>();
      for (BMLSpecificationCase specCase : cases) {
        accum.addAll(Arrays.asList(specCase.getModifies().getStoreRefs()));
      }
      storeRefs = accum.toArray(new BMLStoreRef[accum.size()]);
    }
    return storeRefs;
  }

  private static BMLExpression getExceptionalPostcondition(
      JType exception,
      BMLExsuresClause[] exsures) {
    BMLExpression post = null;
    for (BMLExsuresClause ex : exsures) {
      if (ex.getExceptionType().equals(exception)) {
        if (post == null) {
          post = ex.getPredicate();
        } else {
          post = new BMLBinaryLogicalExpression(
              BMLBinaryLogicalExpression.Operator.AND,
              post,
              ex.getPredicate());
        }
      }
    }
    return (post == null) ? BMLBooleanLiteral.TRUE : post;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();

    for (int i = 0; i < cases.length; i++) {
      if (i > 0) {
        sb.append("also" + System.getProperty("line.separator"));
      }
      sb.append(cases[i]);
    }

    return sb.toString();
  }
}
