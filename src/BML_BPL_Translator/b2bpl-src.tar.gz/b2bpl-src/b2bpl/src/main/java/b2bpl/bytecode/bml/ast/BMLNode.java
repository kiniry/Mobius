package b2bpl.bytecode.bml.ast;


public abstract class BMLNode {

}
