package b2bpl.bytecode.bml.ast;

import b2bpl.bytecode.bml.BMLExpressionVisitor;


public class BMLOldExpression extends BMLExpression {

  private final BMLExpression expression;

  public BMLOldExpression(BMLExpression expression) {
    this.expression = expression;
  }

  public BMLExpression getExpression() {
    return expression;
  }

  public <R> R accept(BMLExpressionVisitor<R> visitor) {
    return visitor.visitOldExpression(this);
  }

  public String toString() {
    return "\\old(" + expression + ")";
  }
}
