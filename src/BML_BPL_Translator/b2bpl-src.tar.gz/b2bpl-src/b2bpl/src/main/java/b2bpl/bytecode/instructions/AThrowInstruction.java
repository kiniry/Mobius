package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.Opcodes;


public class AThrowInstruction extends Instruction {

  public static final AThrowInstruction ATHROW = new AThrowInstruction();

  private AThrowInstruction() {
    super(Opcodes.ATHROW);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitAThrowInstruction(this);
  }

  public String toString() {
    return Opcodes.NAMES[opcode];
  }
}
