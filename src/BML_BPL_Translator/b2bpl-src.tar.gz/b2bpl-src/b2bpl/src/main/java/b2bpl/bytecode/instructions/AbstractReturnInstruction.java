package b2bpl.bytecode.instructions;


public abstract class AbstractReturnInstruction extends Instruction {

  public AbstractReturnInstruction(int opcode) {
    super(opcode);
  }
}
