package b2bpl.bytecode.instructions;


public abstract class ArithmeticInstruction extends Instruction {

  public ArithmeticInstruction(int opcode) {
    super(opcode);
  }
}
