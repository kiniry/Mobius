package b2bpl.bytecode.instructions;


public abstract class ArrayInstruction extends Instruction {

  public ArrayInstruction(int opcode) {
    super(opcode);
  }
}
