package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.Opcodes;


public class ArrayLengthInstruction extends Instruction {

  public static final ArrayLengthInstruction ARRAYLENGTH =
    new ArrayLengthInstruction();

  private ArrayLengthInstruction() {
    super(Opcodes.ARRAYLENGTH);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitArrayLengthInstruction(this);
  }

  public String toString() {
    return Opcodes.NAMES[opcode];
  }
}
