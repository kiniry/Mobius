package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.Opcodes;


public class IALoadInstruction extends Instruction {

  public static final IALoadInstruction IALOAD = new IALoadInstruction();

  private IALoadInstruction() {
    super(Opcodes.IALOAD);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitIALoadInstruction(this);
  }

  public String toString() {
    return Opcodes.NAMES[opcode];
  }
}
