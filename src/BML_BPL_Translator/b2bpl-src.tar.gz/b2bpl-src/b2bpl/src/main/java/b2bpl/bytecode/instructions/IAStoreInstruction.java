package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.Opcodes;


public class IAStoreInstruction extends Instruction {

  public static final IAStoreInstruction IASTORE = new IAStoreInstruction();

  private IAStoreInstruction() {
    super(Opcodes.IASTORE);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitIAStoreInstruction(this);
  }

  public String toString() {
    return Opcodes.NAMES[opcode];
  }
}
