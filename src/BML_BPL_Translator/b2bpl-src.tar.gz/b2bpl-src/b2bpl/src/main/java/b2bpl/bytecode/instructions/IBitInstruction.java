package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.Opcodes;


public class IBitInstruction extends ArithmeticInstruction {

  public static final IBitInstruction ISHL =
    new IBitInstruction(Opcodes.ISHL);

  public static final IBitInstruction ISHR =
    new IBitInstruction(Opcodes.ISHR);

  public static final IBitInstruction IUSHR =
    new IBitInstruction(Opcodes.IUSHR);

  public static final IBitInstruction IAND =
    new IBitInstruction(Opcodes.IAND);

  public static final IBitInstruction IOR =
    new IBitInstruction(Opcodes.IOR);

  public static final IBitInstruction IXOR =
    new IBitInstruction(Opcodes.IXOR);

  private IBitInstruction(int opcode) {
    super(opcode);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitIBitwiseInstruction(this);
  }

  public String toString() {
    return Opcodes.NAMES[opcode];
  }
}
