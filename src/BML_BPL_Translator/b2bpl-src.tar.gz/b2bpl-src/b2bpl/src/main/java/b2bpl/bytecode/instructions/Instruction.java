package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;


public abstract class Instruction {

  protected final int opcode;

  public Instruction(int opcode) {
    this.opcode = opcode;
  }

  public int getOpcode() {
    return opcode;
  }

  public abstract void accept(InstructionVisitor visitor);
}
