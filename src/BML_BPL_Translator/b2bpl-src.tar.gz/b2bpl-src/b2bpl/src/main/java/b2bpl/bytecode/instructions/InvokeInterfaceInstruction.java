package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.JReferenceType;
import b2bpl.bytecode.JType;
import b2bpl.bytecode.Opcodes;


public class InvokeInterfaceInstruction extends InvokeInstruction {

  public InvokeInterfaceInstruction(
      JReferenceType methodOwner,
      String methodName,
      JType returnType,
      JType[] parameterTypes) {
    super(
        Opcodes.INVOKEINTERFACE,
        methodOwner,
        methodName,
        returnType,
        parameterTypes);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitInvokeInterfaceInstruction(this);
  }
}
