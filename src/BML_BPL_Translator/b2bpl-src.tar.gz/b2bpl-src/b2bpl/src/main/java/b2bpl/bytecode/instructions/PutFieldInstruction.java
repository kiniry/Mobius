package b2bpl.bytecode.instructions;

import b2bpl.bytecode.InstructionVisitor;
import b2bpl.bytecode.JReferenceType;
import b2bpl.bytecode.JType;
import b2bpl.bytecode.Opcodes;


public class PutFieldInstruction extends FieldInstruction {

  public PutFieldInstruction(
      JReferenceType fieldOwner,
      String fieldName,
      JType fieldType) {
    super(Opcodes.PUTFIELD, fieldOwner, fieldName, fieldType);
  }

  public void accept(InstructionVisitor visitor) {
    visitor.visitPutFieldInstruction(this);
  }
}
