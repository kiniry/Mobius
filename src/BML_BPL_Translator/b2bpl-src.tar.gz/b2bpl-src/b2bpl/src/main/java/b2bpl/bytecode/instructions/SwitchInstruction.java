package b2bpl.bytecode.instructions;


public abstract class SwitchInstruction extends Instruction {

  public SwitchInstruction(int opcode) {
    super(opcode);
  }
}
