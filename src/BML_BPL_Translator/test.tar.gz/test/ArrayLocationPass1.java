public class ArrayLocationPass1 {

  int field;

  //@ requires arr != null && arr.length > 10;
  public void m1(int[] arr) {
    arr[3] = 77;
    //@ assert (\forall int i; 0 <= i && i < arr.length && i != 3; arr[i] == \old(arr[i]));
    //@ assert field == \old(field);
  }

  //@ requires arr != null && arr.length < 10;
  public void m2(int[] arr) {
    field = 77;
    //@ assert (\forall int i; 0 <= i && i < arr.length; arr[i] == \old(arr[i]));
  }
}
