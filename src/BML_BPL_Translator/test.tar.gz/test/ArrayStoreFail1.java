public class ArrayStoreFail1 {

  //@ invariant faarr1 != null && faarr1.length == 10;

  //@ invariant faarr2 != null && faarr2.length == 10;

  ArrayStoreFail1[] faarr1;

  ArrayStoreFail1[] faarr2;

  public void m1() {
    faarr1[3] = faarr2[3];
  }

  public void m2() {
    faarr1[3] = this;
  }
}
