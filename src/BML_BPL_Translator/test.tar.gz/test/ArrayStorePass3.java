public final class ArrayStorePass3 {

  public void m1(ArrayStorePass3[][] a1, ArrayStorePass3[][] a2) {
    if ((a1 != null) && (a2 != null) && (a1.length > 10) && (a2.length > 10)) {
      a1[3] = a2[2];
      if ((a1[5] != null) && (a2[3] != null)
          && (a1[5].length > 10) && (a2[3].length > 10)) {
        a1[5][1] = a2[3][2];
      }
    }
  }
}
