public class DepositAccountPass1 {

  //@ invariant sum >= 0;

  //@ constraint sum <= \old(sum);

  private int sum;

  /*@
    @ requires n > 0;
    @ modifies sum;
    @ ensures sum <= \old(sum) + n;
    @ exsures (Exception e) false;
    @*/
  public void deposit(int n) {
    int i = 0;
    //@ loop_modifies sum;
    //@ loop_invariant 0 <= i && i <= n && 0 <= sum && sum <= \old(sum) + i;
    //@ decreasing n - i;
    for (i = 0; i < n; i++) {
      sum++;
    }
  }
}
