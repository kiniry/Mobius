public class InitConstructorPass1 {

  int zero;

  int one;

  InitConstructorPass1 nil;

  public InitConstructorPass1() {
    //@ assert zero == 0;
    //@ assert nil == null;
    one++;
    //@ assert one == 1;
  }
}
