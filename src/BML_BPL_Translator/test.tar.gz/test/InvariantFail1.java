public class InvariantFail1 {

  private InvariantFail1 f;

  private InvariantFail1 g;

  //@ invariant f != null;

  public void fail1() {
    //@ assert g != null;
  }

  public void fail2() {
    //@ assert f.g != null;
  }

  public void fail3() {
    //@ assert g.f != null;
  }

  public void fail4() {
    f = null;
  }

  public void fail5() {
    f.f = null;
  }

  public void fail6() {
    f = g;
  }

  public void fail7() {
    f.f = g;
  }
}
