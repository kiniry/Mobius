public class InvariantFail2 {

  int x;

  //@ invariant x > 0;

  //@ modifies \nothing;
  public void foo() {
    // Let it fail to be able to better check the tests (all methods should fail).
    //@ assert false;
  }

  //@ modifies x;
  public void m1() {
    x = -1;
  }

  //@ modifies x;
  public void m2() {
    x = -1;
    x = 0;
    x = -1;
  }

  //@ modifies x;
  public void m3() {
    x = -1;
    foo();
    x = 1;
  }
}
