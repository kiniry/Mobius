public class InvariantFail3 {

  private InvariantFail3 f;

  private InvariantFail3 g;

  //@ invariant f != null;

  public void fail1() {
    if (f != this) {
      f.f = null;
    }
  }

  public void fail2() {
    if (f != this) {
      f.f = g;
    }
  }

  public void fail3() {
    new InvariantFail3().f = null;
  }
}
