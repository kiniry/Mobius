public class InvariantLoopFail1 {

  InvariantLoopFail1 f;

  //@ invariant f != null;

  //@ modifies f;
  public InvariantLoopFail1() {
    this.f = null;
  }

  public void fail1() {
    int i = 0;
    //@ loop_modifies this.f;
    for (i = 0; i < 10; i++) {
      this.f = null;
    }
  }

  public void fail2() {
    int i = 0;
    InvariantLoopFail1 o = new InvariantLoopFail1();
    //@ loop_modifies o.f;
    for (i = 0; i < 10; i++) {
      o.f = null;
    }
  }

  public void fail3() {
    int i = 0;
    //@ loop_modifies \nothing;
    for (i = 0; i < 10; i++) {
      InvariantLoopFail1 o = new InvariantLoopFail1();
      o.f = null;
    }
  }
}
