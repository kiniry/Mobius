public class InvariantLoopPass1 {

  InvariantLoopPass1 f;

  //@ invariant f != null;

  //@ modifies f;
  public InvariantLoopPass1() {
    this.f = this;
  }

  public void pass1() {
    int i = 0;
    InvariantLoopPass1 o = new InvariantLoopPass1();
    //@ loop_modifies this.f, o.f;
    for (i = 0; i < 10; i++) {
      // Break the invariants.
      this.f = null;
      o.f = null;
    }
    // Restore the invariants.
    this.f = this;
    o.f = this;
  }

  public void pass2() {
    int i = 0;
    //@ loop_modifies \nothing;
    for (i = 0; i < 10; i++) {
      InvariantLoopPass1 o = new InvariantLoopPass1();
      o.f = null;
      o.f = this;
    }
  }
}
