public class InvariantNewPass1 {

  private InvariantNewPass1 f;

  //@ invariant f != null;

  //@ modifies f;
  public InvariantNewPass1() {
    this.f = this;
  }

  public void pass() {
    InvariantNewPass1 o = new InvariantNewPass1();
    //@ assert o.f != null;
    //@ assert o.f.f != null;
    f = o.f;
    o.f = f;
  }
}
