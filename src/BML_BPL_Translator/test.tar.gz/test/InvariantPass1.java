public class InvariantPass1 {

  private InvariantPass1 f;

  //@ invariant f != null;

  //@ modifies f;
  public InvariantPass1() {
    this.f = this;
  }

  public void pass() {
    //@ assert f != null;
    //@ assert f.f != null;
    f = f.f;
    f.f = f;
  }
}
