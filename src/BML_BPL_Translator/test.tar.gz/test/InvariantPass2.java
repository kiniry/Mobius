public class InvariantPass2 {

  private int x;

  //@ invariant x >= 0;

  //@ modifies \nothing;
  public void foo() {
    // do nothing
  }

  //@ modifies x;
  public void m1() {
    x = 0;
  }

  //@ modifies x;
  public void m2() {
    x = 1;
  }

  //@ modifies x;
  public void m3() {
    x = -1;
    x = 0;
  }

  //@ modifies x;
  public void m4() {
    x = -1;
    x = 0;
    foo();
  }
}
