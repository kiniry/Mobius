public class InvariantPass3 {

  private InvariantPass3 f;

  private InvariantPass3 g;

  //@ invariant f != null;

  //@ modifies f;
  public InvariantPass3() {
    this.f = this;
  }

  public void pass1() {
    if (f != this) {
      f.g = null;
    }
  }

  public void pass2() {
    if (f != this) {
      f.g = g;
    }
  }

  public void fail3() {
    new InvariantPass3().g = null;
  }
}
