public class InvariantSuperConstructorFail1 {

  //@ invariant superfield != null;

  InvariantSuperConstructorFail1 superfield;
}

class InvariantSuperConstructorSubFail1 extends InvariantSuperConstructorFail1 {

  //@ invariant subfield != null;

  InvariantSuperConstructorSubFail1 subfield;

  public InvariantSuperConstructorSubFail1() {
    super();
    //@ assert subfield != null;
  }

  public InvariantSuperConstructorSubFail1(Object o) {
    super();
    superfield = null;
    subfield = this;
  }
}
