public class InvariantSuperConstructorPass1 {

  //@ invariant superfield != null;

  InvariantSuperConstructorPass1 superfield;

  public InvariantSuperConstructorPass1() {
    superfield = this;
  }
}

class InvariantSuperConstructorSubPass1 extends InvariantSuperConstructorPass1 {

  //@ invariant subfield != null;

  InvariantSuperConstructorSubPass1 subfield;

  public InvariantSuperConstructorSubPass1() {
    super();
    //@ assert superfield != null;
    subfield = this;
  }

  public InvariantSuperConstructorSubPass1(Object o) {
    super();
    superfield = this;
    subfield = this;
  }
}
