public class LoopModifiesNewPass1 {

  private int sum;

  //@ modifies \nothing;
  public LoopModifiesNewPass1() {
  }

  //@ requires n > 0;
  public void m1(int n) {
    int i = 0;
    //@ loop_modifies \nothing;
    //@ decreasing n - i;
    for (i = 0; i < n; i++) {
      LoopModifiesNewPass1[] arr = new LoopModifiesNewPass1[n];
      //@ loop_modifies arr[*];
      //@ loop_invariant 0 <= j;
      //@ decreasing n - j;
      for (int j = 0; j < n; j++) {
        arr[j] = new LoopModifiesNewPass1();
        arr[j].sum = sum;
      }
    }
  }

  //@ requires n > 10;
  public void m2(int n) {
    int i = 0;
    //@ loop_modifies \nothing;
    for (i = 0; i < 100; i++) {
      LoopModifiesNewPass1[][] arr = new LoopModifiesNewPass1[n][n];
      arr[0] = null;
      arr[1] = arr[2];
      arr[3][4] = new LoopModifiesNewPass1();
      arr[3][4].sum = sum;
    }
  }
}
