public class LoopVariantFail1 {

  public LoopVariantFail1() {
    // Make sure all methods in the class fail (for testing purposes).
    //@ assert false;
  }

  public void fail1() {
    int i = 0;
    // The non-negativity of the loop variant is violated at the end of
    // the loop.
    //@ decreasing 10 - i;
    for (i = 0; i <= 10; i++) {
      i++;
    }
  }

  public void fail2() {
    int i = 0;
    // The loop variant function does not decrease.
    //@ decreasing 10 - i;
    for (i = 0; i < 10; i++) {
      i--;
    }
  }
}
