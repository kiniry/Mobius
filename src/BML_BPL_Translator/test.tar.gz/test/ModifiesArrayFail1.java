public final class ModifiesArrayFail1 {

  //@ invariant fiarr != null && fiarr.length == 10;

  //@ invariant faarr != null && faarr.length == 10;

  int fi;

  int[] fiarr;

  ModifiesArrayFail1[] faarr;

  //@ modifies fiarr[3];
  public void m1() {
    fiarr[2] = 77;
  }

  //@ modifies faarr[3];
  public void m2() {
    faarr[2] = null;
  }

  //@ modifies faarr[3].fi;
  public void m3() {
    if (faarr[2] != null) {
      faarr[2].fi = 77;
    }
  }

  //@ modifies \nothing;
  public void m4() {
    ModifiesArrayFail1[] a = new ModifiesArrayFail1[10];
    a[3] = this;
    a[3].fi = 77;
  }
}
