public final class ModifiesArrayPass1 {

  //@ invariant fiarr != null && fiarr.length == 10;

  //@ invariant faarr != null && faarr.length == 10;

  int fi;

  int[] fiarr;

  ModifiesArrayPass1[] faarr;

  //@ modifies fiarr, faarr;
  public ModifiesArrayPass1() {
    fiarr = new int[10];
    faarr = new ModifiesArrayPass1[10];
  }

  //@ modifies fiarr[3];
  public void m1() {
    fiarr[3] = 77;
  }

  //@ modifies faarr[3];
  public void m2() {
    faarr[3] = null;
  }

  //@ modifies \nothing;
  public void m3() {
    if (faarr[3] == null) {
      faarr[3] = null;
    }
  }

  //@ modifies \nothing;
  public void m4() {
    ModifiesArrayPass1 tmp = faarr[3];
    faarr[3] = null;
    faarr[3] = tmp;
  }

  //@ modifies faarr[3].fi;
  public void m5() {
    if (faarr[3] != null) {
      faarr[3].fi = 77;
    }
  }

  //@ modifies faarr[3].fi;
  public void m6() {
    if (this == faarr[3]) {
      faarr[3].fi = 77;
      this.fi = 88;
    }
  }

  //@ modifies \nothing;
  public void m7() {
    ModifiesArrayPass1[] a = new ModifiesArrayPass1[10];
    a[3] = new ModifiesArrayPass1();
    a[3].fi = 77;
  }
}
