public final class ModifiesFail1 {

  //@ invariant f != null && arr != null && arr.length == 10;

  ModifiesFail1 f;

  ModifiesFail1[] arr;

  //@ modifies \nothing;
  public ModifiesFail1() {
    // Let all the methods fail for easier testing.
    //@ assert false;
  }

  //@ modifies arr[*];
  public void m1() {
    f = this;
  }

  //@ modifies f;
  public void m2() {
    arr[2] = this;
  }

  //@ modifies f, arr[3].f;
  public void m3() {
    if (arr[2] != null) {
      arr[2].f = null;
    }
  }

  //@ modifies \nothing;
  public void m4() {
    ModifiesNewPass1 n = new ModifiesNewPass1();
    if (n.arr[3] != null) {
      n.arr[3].f = null;
    }
  }

  //@ modifies \nothing;
  public void m5() {
    ModifiesFail1[] a = new ModifiesFail1[10];
    a[3] = this;
    a[3].f = this;
  }
}
