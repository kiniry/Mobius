public final class ModifiesNewFail1 {

  //@ invariant f != null && arr != null && arr.length == 10;

  ModifiesNewFail1 f;

  ModifiesNewFail1[] arr;

  //@ modifies f, arr;
  public ModifiesNewFail1() {
    // Let all the methods fail for easier testing.
    //@ assert false;
  }

  //@ modifies \nothing;
  public void m1() {
    new ModifiesNewFail1().arr[2] = this;
  }

  //@ modifies \nothing;
  public void m2() {
    ModifiesNewFail1 n = new ModifiesNewFail1();
    n.arr[3] = new ModifiesNewFail1();
    n.arr[3].f = this;
  }
}
