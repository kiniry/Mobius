public final class ModifiesNewPass1 {

  //@ invariant f != null && arr != null && arr.length == 10;

  ModifiesNewPass1 f;

  ModifiesNewPass1[] arr;

  //@ modifies f, arr;
  public ModifiesNewPass1() {
    f = this;
    arr = new ModifiesNewPass1[10];
  }

  //@ modifies \nothing;
  public void m1() {
    new ModifiesNewPass1().f = this;
  }

  //@ modifies \nothing;
  public void m2() {
    ModifiesNewPass1[] a = new ModifiesNewPass1[10];
    a[3] = new ModifiesNewPass1();
    a[3].f = this;
  }
}
