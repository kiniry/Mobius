public final class ModifiesPass1 {

  //@ invariant f != null && arr != null && arr.length == 10;

  ModifiesPass1 f;

  ModifiesPass1[] arr;

  //@ modifies f, arr;
  public ModifiesPass1() {
    f = this;
    arr = new ModifiesPass1[10];
  }

  //@ modifies f;
  public void m1() {
    f = this;
  }

  //@ modifies arr[*];
  public void m2() {
    arr[2] = this;
  }

  //@ modifies f, arr[3].f;
  public void m3() {
    if (arr[3] != null) {
      arr[3].f = this;
    }
  }
}
