public class MultiANewArrayFail1 {

  public MultiANewArrayFail1() {
    // Force all the methods to fail for easier testing.
    //@ assert false;
  }

  public void fail1() {
    MultiANewArrayFail1[][] arr = new MultiANewArrayFail1[10][5];
    //@ assert arr[3][2] != null;
  }

  public void fail2() {
    int[][][] arr = new int[5][10][];
    //@ assert arr[4][8] != null;
  }
}
