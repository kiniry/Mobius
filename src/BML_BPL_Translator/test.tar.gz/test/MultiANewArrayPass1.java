public class MultiANewArrayPass1 {

  public void pass1(Object o) {
    MultiANewArrayPass1[][] arr = new MultiANewArrayPass1[10][5];
    //@ arr != null;
    //@ arr != o;
    //@ assert arr.length == 10;
    //@ assert arr[2].length == 5;
    //@ assert arr[3] != null;
    //@ assert arr[3] != arr[5];
    //@ assert arr[6] != o;
  }

  public void pass2(Object o) {
    int[][] arr = new int[10][5];
    //@ arr != null;
    //@ arr != o;
    //@ assert arr.length == 10;
    //@ assert arr[2].length == 5;
    //@ assert arr[3] != null;
    //@ assert arr[3] != arr[5];
    //@ assert arr[6] != o;
  }

  public void pass3(Object o) {
    int[][][] arr = new int[5][10][15];
    //@ arr != null;
    //@ arr != o;
    //@ assert arr.length == 5;
    //@ assert arr[3].length == 10;
    //@ assert arr[2][9].length == 15;
    //@ assert arr[2] != null;
    //@ assert arr[4][8] != null;
    //@ assert arr[3] != arr[0];
    //@ assert arr[3][7] != arr[4][7];
    //@ assert arr[3][7] != arr[3][5];
    //@ assert arr[1] != o;
    //@ assert arr[0][3] != o;
  }
}
