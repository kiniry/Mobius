public class NewDistinctPass1 {

  public void foo(NewDistinctPass1 p1) {
    NewDistinctPass1 o1 = new NewDistinctPass1();
    NewDistinctPass1 o2 = new NewDistinctPass1();
    //@ assert o1 != o2;
    //@ assert o1 != p1;
  }
}
