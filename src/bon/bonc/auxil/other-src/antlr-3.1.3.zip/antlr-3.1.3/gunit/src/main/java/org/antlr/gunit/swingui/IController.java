package org.antlr.gunit.swingui;

import java.awt.Component;

public interface IController {
    public Object getModel() ;
    public Component getView() ;
}
