/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.antlr.gunit.swingui.model;

/**
 *
 * @author scai
 */
public interface ITestCaseOutput {
    public void setScript(String script);
    public String getScript() ;
}
