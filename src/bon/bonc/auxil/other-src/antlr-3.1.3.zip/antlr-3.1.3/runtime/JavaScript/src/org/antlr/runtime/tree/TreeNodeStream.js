/** A stream of tree nodes, accessing nodes from a tree of some kind */
org.antlr.runtime.tree.TreeNodeStream = function() {};

org.antlr.lang.extend(org.antlr.runtime.tree.TreeNodeStream,
                      org.antlr.runtime.IntStream);

