package cvc3;

import java.util.*;

public class Context extends Embedded {
    // jni methods

    /// Constructor

    public Context(Object Context, EmbeddedManager embeddedManager) {
	super(Context, embeddedManager);
    }


    /// API (immutable)

}
