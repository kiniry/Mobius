DEFINITION: Java_cvc3_EmbeddedManager_jniDelete
void n jobject obj
deleteEmbedded(env, jobj);
