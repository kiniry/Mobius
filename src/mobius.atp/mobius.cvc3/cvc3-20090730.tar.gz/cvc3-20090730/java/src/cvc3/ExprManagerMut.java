package cvc3;

import java.util.*;

public class ExprManagerMut extends ExprManager {
    // jni methods

    /// Constructor

    public ExprManagerMut(Object ExprManagerMut, EmbeddedManager embeddedManager) {
	super(ExprManagerMut, embeddedManager);
    }


    /// API (mutable)
}
