package com.sun.java.swing.plaf.windows;

import java.awt.*;
import java.beans.*;
import java.lang.ref.*;
import javax.swing.*;
import javax.swing.plaf.*;

class DesktopProperty$1 implements Runnable {
    /*synthetic*/ final DesktopProperty this$0;
    
    DesktopProperty$1(/*synthetic*/ final DesktopProperty this$0) {
        this.this$0 = this$0;
        super();
    }
    
    public void run() {
        DesktopProperty.access$000();
        DesktopProperty.access$100(false);
    }
}
