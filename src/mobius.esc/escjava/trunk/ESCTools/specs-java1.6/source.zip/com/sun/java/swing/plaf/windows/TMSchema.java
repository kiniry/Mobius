package com.sun.java.swing.plaf.windows;

import java.awt.*;
import java.util.*;
import javax.swing.*;

class TMSchema {
    
    TMSchema() {
        super();
    }
    {
    }
    {
    }
    {
    }
    {
    }
    {
    }
}
