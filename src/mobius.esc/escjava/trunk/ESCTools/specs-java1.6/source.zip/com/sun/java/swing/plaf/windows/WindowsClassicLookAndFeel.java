package com.sun.java.swing.plaf.windows;

public class WindowsClassicLookAndFeel extends WindowsLookAndFeel {
    
    public WindowsClassicLookAndFeel() {
        super();
    }
}
