package com.sun.java.swing.plaf.windows;

import javax.swing.*;
import java.awt.*;
import com.sun.java.swing.plaf.windows.TMSchema.*;

class WindowsIconFactory$1 {
}
