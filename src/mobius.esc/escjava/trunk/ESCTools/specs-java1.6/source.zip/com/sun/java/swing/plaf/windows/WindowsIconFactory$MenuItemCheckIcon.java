package com.sun.java.swing.plaf.windows;

import javax.swing.*;
import javax.swing.plaf.UIResource;
import java.awt.*;
import java.io.Serializable;
import com.sun.java.swing.plaf.windows.TMSchema.*;

class WindowsIconFactory$MenuItemCheckIcon implements Icon, UIResource, Serializable {
    
    /*synthetic*/ WindowsIconFactory$MenuItemCheckIcon(com.sun.java.swing.plaf.windows.WindowsIconFactory$1 x0) {
        this();
    }
    
    private WindowsIconFactory$MenuItemCheckIcon() {
        super();
    }
    
    public void paintIcon(Component c, Graphics g, int x, int y) {
    }
    
    public int getIconWidth() {
        return 9;
    }
    
    public int getIconHeight() {
        return 9;
    }
}
