package com.sun.java.swing.plaf.windows;

import java.awt.*;
import javax.swing.plaf.*;
import javax.swing.*;
import javax.swing.plaf.basic.*;
import javax.swing.border.*;
import java.util.*;
import com.sun.java.swing.plaf.windows.TMSchema.*;
import com.sun.java.swing.plaf.windows.XPStyle.Skin;

class WindowsLookAndFeel$XPColorValue$XPColorValueKey {
    XPStyle$Skin skin;
    TMSchema$Prop prop;
    
    WindowsLookAndFeel$XPColorValue$XPColorValueKey(TMSchema$Part part, TMSchema$State state, TMSchema$Prop prop) {
        super();
        this.skin = new XPStyle$Skin(part, state);
        this.prop = prop;
    }
}
