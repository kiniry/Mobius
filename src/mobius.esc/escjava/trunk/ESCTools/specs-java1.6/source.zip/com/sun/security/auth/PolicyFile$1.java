package com.sun.security.auth;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

class PolicyFile$1 implements java.security.PrivilegedAction {
    
    PolicyFile$1() {
        super();
    }
    
    public Object run() {
        return (java.util.ResourceBundle.getBundle("sun.security.util.AuthResources"));
    }
}
