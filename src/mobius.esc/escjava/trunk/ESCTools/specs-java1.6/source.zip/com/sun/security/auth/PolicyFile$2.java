package com.sun.security.auth;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

class PolicyFile$2 implements java.security.PrivilegedAction {
    /*synthetic*/ final PolicyFile this$0;
    
    PolicyFile$2(/*synthetic*/ final PolicyFile this$0) {
        this.this$0 = this$0;
        super();
    }
    
    public Object run() {
        PolicyFile.access$000(this$0);
        return null;
    }
}
