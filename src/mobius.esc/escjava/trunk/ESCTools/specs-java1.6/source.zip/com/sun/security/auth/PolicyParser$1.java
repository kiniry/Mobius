package com.sun.security.auth;

import java.io.*;

class PolicyParser$1 implements java.security.PrivilegedAction {
    
    PolicyParser$1() {
        super();
    }
    
    public Object run() {
        return (java.util.ResourceBundle.getBundle("sun.security.util.AuthResources"));
    }
}
