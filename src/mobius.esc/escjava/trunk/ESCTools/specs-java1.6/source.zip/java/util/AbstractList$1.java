package java.util;

class AbstractList$1 {
}
