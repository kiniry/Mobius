package java.util;

class EnumMap$1 {
}
