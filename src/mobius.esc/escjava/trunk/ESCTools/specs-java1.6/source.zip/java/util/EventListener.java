package java.util;

public interface EventListener {
}
