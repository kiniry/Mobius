package java.util;

public class FormatterClosedException extends IllegalStateException {
    private static final long serialVersionUID = 18111216L;
    
    public FormatterClosedException() {
        super();
    }
}
