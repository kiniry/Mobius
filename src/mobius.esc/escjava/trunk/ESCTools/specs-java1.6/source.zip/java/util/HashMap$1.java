package java.util;

import java.io.*;

class HashMap$1 {
}
