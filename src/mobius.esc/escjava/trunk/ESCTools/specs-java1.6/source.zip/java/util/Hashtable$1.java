package java.util;

import java.io.*;

class Hashtable$1 {
}
