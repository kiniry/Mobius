package java.util;

import java.io.*;

class Hashtable$EmptyEnumerator implements Enumeration {
    
    Hashtable$EmptyEnumerator() {
        super();
    }
    
    public boolean hasMoreElements() {
        return false;
    }
    
    public Object nextElement() {
        throw new NoSuchElementException("Hashtable Enumerator");
    }
}
