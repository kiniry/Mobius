package java.util;

import java.io.*;

class IdentityHashMap$1 {
}
