package java.util;

public class InputMismatchException extends NoSuchElementException {
    
    public InputMismatchException() {
        super();
    }
    
    public InputMismatchException(String s) {
        super(s);
    }
}
