package java.util;

public class NoSuchElementException extends RuntimeException {
    
    public NoSuchElementException() {
        super();
    }
    
    public NoSuchElementException(String s) {
        super(s);
    }
}
