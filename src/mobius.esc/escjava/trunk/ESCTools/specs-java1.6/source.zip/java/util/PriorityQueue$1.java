package java.util;

class PriorityQueue$1 {
}
