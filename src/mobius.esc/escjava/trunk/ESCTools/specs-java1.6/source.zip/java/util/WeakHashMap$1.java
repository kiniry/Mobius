package java.util;

class WeakHashMap$1 {
}
