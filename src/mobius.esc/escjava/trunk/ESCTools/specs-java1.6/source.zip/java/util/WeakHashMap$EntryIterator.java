package java.util;

class WeakHashMap$EntryIterator extends WeakHashMap$HashIterator {
    
    /*synthetic*/ WeakHashMap$EntryIterator(WeakHashMap x0, java.util.WeakHashMap$1 x1) {
        this(x0);
    }
    /*synthetic*/ final WeakHashMap this$0;
    
    private WeakHashMap$EntryIterator(/*synthetic*/ final WeakHashMap this$0) {
        this.this$0 = this$0;
        super(this$0);
    }
    
    public Map$Entry next() {
        return nextEntry();
    }
    
    /*synthetic*/ public Object next() {
        return this.next();
    }
}
