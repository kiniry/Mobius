package java.util.concurrent;

public interface Callable {
    
    Object call() throws Exception;
}
