package java.util.concurrent;

import java.util.concurrent.locks.*;

class CyclicBarrier$1 {
}
