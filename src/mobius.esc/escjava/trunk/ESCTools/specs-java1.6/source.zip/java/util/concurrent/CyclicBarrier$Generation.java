package java.util.concurrent;

import java.util.concurrent.locks.*;

class CyclicBarrier$Generation {
    
    /*synthetic*/ CyclicBarrier$Generation(java.util.concurrent.CyclicBarrier$1 x0) {
        this();
    }
    
    private CyclicBarrier$Generation() {
        super();
    }
    boolean broken = false;
}
