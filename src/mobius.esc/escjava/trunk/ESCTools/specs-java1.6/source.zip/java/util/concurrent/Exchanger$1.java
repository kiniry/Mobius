package java.util.concurrent;

import java.util.concurrent.atomic.*;

class Exchanger$1 {
}
