package java.util.concurrent;

import java.util.concurrent.atomic.*;

final class Exchanger$Slot extends AtomicReference {
    
    /*synthetic*/ Exchanger$Slot(java.util.concurrent.Exchanger$1 x0) {
        this();
    }
    
    private Exchanger$Slot() {
        super();
    }
    long q0;
    long q1;
    long q2;
    long q3;
    long q4;
    long q5;
    long q6;
    long q7;
    long q8;
    long q9;
    long qa;
    long qb;
    long qc;
    long qd;
    long qe;
}
