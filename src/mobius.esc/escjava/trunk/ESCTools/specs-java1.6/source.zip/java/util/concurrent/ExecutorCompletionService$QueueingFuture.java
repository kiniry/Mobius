package java.util.concurrent;

class ExecutorCompletionService$QueueingFuture extends FutureTask {
    /*synthetic*/ final ExecutorCompletionService this$0;
    
    ExecutorCompletionService$QueueingFuture(/*synthetic*/ final ExecutorCompletionService this$0, Callable c) {
        this.this$0 = this$0;
        super(c);
    }
    
    ExecutorCompletionService$QueueingFuture(/*synthetic*/ final ExecutorCompletionService this$0, Runnable t, Object r) {
        this.this$0 = this$0;
        super(t, r);
    }
    
    protected void done() {
        ExecutorCompletionService.access$000(this$0).add(this);
    }
}
