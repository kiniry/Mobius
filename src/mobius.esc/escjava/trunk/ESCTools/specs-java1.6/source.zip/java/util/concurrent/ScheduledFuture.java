package java.util.concurrent;

public interface ScheduledFuture extends Delayed, Future {
}
