package java.util.concurrent;

import java.util.concurrent.locks.*;
import java.util.*;

public class ThreadPoolExecutor$DiscardPolicy implements RejectedExecutionHandler {
    
    public ThreadPoolExecutor$DiscardPolicy() {
        super();
    }
    
    public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
    }
}
