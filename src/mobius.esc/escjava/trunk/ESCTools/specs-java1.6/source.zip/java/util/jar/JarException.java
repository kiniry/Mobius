package java.util.jar;

public class JarException extends java.util.zip.ZipException {
    
    public JarException() {
        super();
    }
    
    public JarException(String s) {
        super(s);
    }
}
