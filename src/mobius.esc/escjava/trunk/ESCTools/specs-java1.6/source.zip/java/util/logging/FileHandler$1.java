package java.util.logging;

import java.io.*;
import java.security.*;

class FileHandler$1 implements PrivilegedAction {
    /*synthetic*/ final FileHandler this$0;
    
    FileHandler$1(/*synthetic*/ final FileHandler this$0) {
        this.this$0 = this$0;
        super();
    }
    
    public Object run() {
        FileHandler.access$100(this$0);
        return null;
    }
}
