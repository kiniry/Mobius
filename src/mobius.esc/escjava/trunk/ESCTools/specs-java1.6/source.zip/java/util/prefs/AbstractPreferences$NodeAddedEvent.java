package java.util.prefs;

import java.util.*;
import java.io.*;

class AbstractPreferences$NodeAddedEvent extends NodeChangeEvent {
    /*synthetic*/ final AbstractPreferences this$0;
    private static final long serialVersionUID = -6743557530157328528L;
    
    AbstractPreferences$NodeAddedEvent(/*synthetic*/ final AbstractPreferences this$0, Preferences parent, Preferences child) {
        this.this$0 = this$0;
        super(parent, child);
    }
}
