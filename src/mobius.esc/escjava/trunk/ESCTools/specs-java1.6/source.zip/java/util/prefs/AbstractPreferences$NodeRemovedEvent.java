package java.util.prefs;

import java.util.*;
import java.io.*;

class AbstractPreferences$NodeRemovedEvent extends NodeChangeEvent {
    /*synthetic*/ final AbstractPreferences this$0;
    private static final long serialVersionUID = 8735497392918824837L;
    
    AbstractPreferences$NodeRemovedEvent(/*synthetic*/ final AbstractPreferences this$0, Preferences parent, Preferences child) {
        this.this$0 = this$0;
        super(parent, child);
    }
}
