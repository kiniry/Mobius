package java.util.prefs;

import java.util.*;
import java.io.*;
import java.security.PrivilegedExceptionAction;

class FileSystemPreferences$13 implements PrivilegedExceptionAction {
    /*synthetic*/ final FileSystemPreferences this$0;
    
    FileSystemPreferences$13(/*synthetic*/ final FileSystemPreferences this$0) throws BackingStoreException {
        this.this$0 = this$0;
        super();
    }
    
    public Object run() throws BackingStoreException {
        FileSystemPreferences.access$2300(this$0);
        return null;
    }
}
