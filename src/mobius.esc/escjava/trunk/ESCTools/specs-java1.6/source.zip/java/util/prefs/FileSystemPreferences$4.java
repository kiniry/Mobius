package java.util.prefs;

import java.util.*;
import java.io.*;

class FileSystemPreferences$4 extends TimerTask {
    
    FileSystemPreferences$4() {
        super();
    }
    
    public void run() {
        FileSystemPreferences.access$1200();
    }
}
