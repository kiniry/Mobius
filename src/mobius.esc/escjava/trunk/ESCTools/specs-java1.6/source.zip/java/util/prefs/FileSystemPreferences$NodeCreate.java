package java.util.prefs;

import java.util.*;
import java.io.*;

class FileSystemPreferences$NodeCreate extends FileSystemPreferences$Change {
    
    /*synthetic*/ FileSystemPreferences$NodeCreate(FileSystemPreferences x0, java.util.prefs.FileSystemPreferences$1 x1) {
        this(x0);
    }
    /*synthetic*/ final FileSystemPreferences this$0;
    
    private FileSystemPreferences$NodeCreate(/*synthetic*/ final FileSystemPreferences this$0) {
        this.this$0 = this$0;
        super(this$0, null);
    }
    
    void replay() {
    }
}
