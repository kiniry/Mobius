public class ArrayBounds {
  public static int goodMiddle(int a[]) {
    return a.length > 0? a[a.length / 2] : -1;
  }

  public static int badMiddle(int a[]) {
    return a[a.length / 2];
  }
}
