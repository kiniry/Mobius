public class DivByZero {
  public static int badGcd(int a, int b) {
    return badGcd(b, a % b);
  }

  public static int goodGcd(int a, int b) {
    if (b == 0) return a;
    return goodGcd(b, a % b);
  }
}
