public class NonnullByDefault {
  public static int len(int a[]) {
    return a.length;
  }

  public static void main(String[] args) {
    len(null);
  }
}
